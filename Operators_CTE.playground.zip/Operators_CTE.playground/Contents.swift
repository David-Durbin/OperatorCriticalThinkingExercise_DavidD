//: Playground - noun: a place where people can play

import UIKit

//var str = "Hello, playground"

// variables x as a flag variable, clsTemp will hold Celsius temperature and constant fhTemp holds 
// fahrenheit temperature of 32 degrees
var x = 0.0
let fhTemp = 32.0
var clsTemp : Double = 0.0

// calculate the celsius equivalent of 32 degreees fahrenheit

clsTemp = (5/9) * (fhTemp - 32)

// print clsTemp

//print("The Celsius equivalent of ", fhTemp, " degrees Fahrenheit is ", clsTemp, " degrees.")

//
x = fhTemp


while  x <= 92  {
        clsTemp = (5/9) * (x - 32)
        print("The Celsius equivalent of ", x, " degrees Fahrenheit is ", clsTemp, " degrees.")
        x += 3
}


